package constant

const ValueEmpty int = 0

var ReplyMsg = []string{
	"Xin chào: %s, tôi là %s, đây là hệ thống tự động!",
	"Xin chào: %s, tôi là %s",
	"Xin chào: %s, tôi là %s, tôi có thể giúp gì cho bạn?",
	"Xin chào: %s, tôi là %s, bạn đang tham gia vào group này!",
}
