package error_base

const (
	ErrorBindDataCodeMsg string = "Failed to bind data"
	ErrorValidDataMsg    string = "Failed to valid data"

	ErrorSendDataMsg     string = "Failed to send data"
)
