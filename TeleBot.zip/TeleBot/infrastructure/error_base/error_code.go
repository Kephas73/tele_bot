package error_base

const (
	ErrorBindDataCode  uint32 = 40000
	ErrorValidDataCode uint32 = 40001

	ErrorSendDataCode uint32 = 50000
)
